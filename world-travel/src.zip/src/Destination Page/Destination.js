import React from 'react'
import DestinationsContainer from './DestinationsContainer'
import Footer from '../Landing/HomePage/Footer'

const Destination = () => {
  return (
    <div>
      <DestinationsContainer />
      <br />
      <br />
      <Footer />
    </div>
  )
}

export default Destination