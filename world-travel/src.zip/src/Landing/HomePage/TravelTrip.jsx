import styled from "styled-components";

function TravelTrip() {
  return (
    <DIV className="shadow d-flex justify-content-between align-items-center">
      {/* <img src="https://images.unsplash.com/photo-1510917203414-2e642e75d3ab?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80" alt="" /> */}
      <div className="row d-flex justify-content-between align-items-center">
        <div className="col-md-6  problems">
          <h1 className="my-4 ps-5">Problems</h1>
          <div className="texts" >
            <p className="my-3">
              Many young people or students want to see the world, get away from
              everyday life or gain inspiration, but do not have a good
              financial situation, or want to encourage. Then they start looking
              for opportunities and cheaper options in social networks and the
              Internet. Most successful people achieve success precisely by saving or
              using cheap labor.
            </p>
            <p className="my-3">The last option allows you to attract people
              from different countries of the world, but their search is quite
              painstaking and long.</p>
          </div>
        </div>
        <div className="col-md-6 goals">
          <h1 className="my-4 ps-5">Goals</h1>
          <div className="texts" >
            <p className="my-3">
              The idea of creating a web service was to combine the search for
              cheap housing for people with the opportunity to travel and see
              the world, find ne acquaintances, gain experience and search for
              cheap labor. Homeowners can provide it for a small fee or for
              free, or for performing any household work.
            </p>
            <p className="my-3">It is the web service that will help find the necessary option for
              both provider or a person who needs household help, as
              well as people who want to travel while saving money.</p>
          </div>
        </div>
      </div>
    </DIV>
  );
}
export default TravelTrip;

const DIV = styled.div`
  color: white;

  padding : 30px;
  margin-top: 25px;
  background-image: url("https://images.unsplash.com/photo-1557307496-494c7611661a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  box-shadow: 10px 10px 5px #ccc;
      -moz-box-shadow: 10px 10px 5px #ccc;
      -webkit-box-shadow: 10px 10px 5px #ccc;
      -khtml-box-shadow: 10px 10px 5px #ccc;

  /* img {
    height: 100%;
    width: 100%;
  } */

  .problems, .goals {
    height : 70%;
  }

  h1 {
    -webkit-text-stroke-width: 1px;
    -webkit-text-stroke-color: white;
    color : white;
  }

  p {
    padding : 10px 2px;
    font-weight: bold;
  }

  .texts {
    backdrop-filter: blur(7px);
  }

`;
